package com.zoho_Inc.Quiz_App_Client;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zoho_Inc.Quiz_App_Client.PlayerManager.Category;

public class Client {
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;

	String plname;
	private Person p;

	public Client(Socket socket, String plName, String password) {
		try {
			this.socket = socket;
			this.plname = plName;
			this.oos = new ObjectOutputStream(socket.getOutputStream());
			this.ois = new ObjectInputStream(socket.getInputStream());
			System.out.println("C: Inside constructor..");
			oos.writeObject(plName);
			oos.flush();

			oos.writeObject(password);
			oos.flush();

			// Receive the JSON string from the server using your preferred method (e.g.,
			// ObjectInputStream)
			String receivedJson = (String) ois.readObject();

			// Deserialize the JSON string into a Person object
			ObjectMapper objectMapper = new ObjectMapper();
			p = objectMapper.readValue(receivedJson, Person.class);

			// Now, you have the received Person object
			System.out.println("Received Person: " + p);
		} catch (IOException e) {
			closeEverything(socket, oos, ois);
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		String url = "localhost";
		int port = 1230;
		Scanner sc = new Scanner(System.in);
//        System.out.println("QUIZ APP CS?");
		System.out.println("\n  Enter your username to play the game: \n");
		String userName = sc.nextLine();
		System.out.println("\n  Enter your password to play the game: \n");
		String password = sc.nextLine();
		try {
			Socket socket = new Socket(url, port);
			Client client = new Client(socket, userName, password);
//			PlayerManager pM = new PlayerManager();
			client.startGameHelper(sc);
		} catch (Exception e) {
			System.out.println("An exception occured.." + e.getMessage());
		}
	}

	public Person getPerson() {
		return p;
	}

	public static void closeEverything(Socket socket, ObjectOutputStream objectOutputStream,
			ObjectInputStream objectInputStream) {
		try {
			if (objectInputStream != null) {
				objectInputStream.close();
			}
			if (objectOutputStream != null) {
				objectOutputStream.close();
			}
			if (socket != null) {
				socket.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void startGameHelper(Scanner sc) {
		try {
			PlayerManager pM = new PlayerManager();
			System.out.println("Connection there");
			while (true) {
				System.out.println("\nC: Enter your choice: ");
				int choice = PlayerManager.validChoices(sc);
				oos.writeInt(choice);
				oos.flush();

				switch (choice) {
				case 1: {
					pM.playGameHelper(p, sc, socket, oos, ois, false, true, null, new ArrayList<Question>());
				}
					break;
				case 2: {
					pM.playGameHelper(p, sc, socket, oos, ois, true, true, null, new ArrayList<Question>());
				}
					break;
				case 3: {
					pM.getAllCategories(oos, ois, new ArrayList<>(), new HashMap<>());
				}
					break;
				case 4: {
					pM.getAllQuestions(oos, ois);
				}
					break;
				case 5: {
					pM.getLog(p, sc, socket, oos, ois);
				}
					break;
				case 6: {
					pM.getTopPlayersPercentWise(oos, ois);
				}
					break;
				case 7: {
					pM.attemptQuiz(p, sc, socket, oos, ois);
				}
					break;
				case 8: {
					closeEverything(socket, oos, ois);
					System.out.println("Exiting Quiz Application. Goodbye!");
					System.exit(0);
				}
					break;
				default:
					System.out.println("Invalid choice. Please try again.");
					break;
				}

			}
		} catch (SocketException e) {
			// Handle the SocketException (Connection reset) gracefully
			System.out.println("Client disconnected unexpectedly.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
