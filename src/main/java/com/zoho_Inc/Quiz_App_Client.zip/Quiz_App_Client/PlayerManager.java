package com.zoho_Inc.Quiz_App_Client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.util.*;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
public class PlayerManager {
	
	static int validChoices(Scanner sc) {
        int choice = 0;

        while (true) {
            try {
                System.out.println("\t\n*** QUIZ APPLICATION MENU ***\n");
                System.out.println("\t1. Play Game");
                System.out.println("\t2. Play Game Category Wise");
                System.out.println("\t3. View All Questions");
                System.out.println("\t4. View All Options For a Question");
                System.out.println("\t6. EXIT\n");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                break;
            } catch (Exception e) {
                System.out.println("Please enter a valid integer choice.\n");
                sc.next();
            }
        }

        return choice;
    }
	
	 public static void displayQuestions(List<Question> questions) {
	        System.out.println("Questions:");
	        for (Question question : questions) {
	            System.out.println("ID: " + question.getId());
	            System.out.println("Question: " + question.getQuestionText());
	            System.out.println("Category ID: " + question.getCategoryId());
	            System.out.println("Answer ID: " + question.getAnswerId());
	            System.out.println("-----------------------------");
	        }
	    }
	 
	 static void displayOptions(List<Option> options) {
		    for (Option option : options) {
		        System.out.println(option);
		    }
	}
	 
//	 static void playGame(Person p, int categoryId, ObjectOutputStream oos, ObjectInputStream ois, Socket socket) {
//	        try {
//	            // Receive questions from the server
//	            List<Question> questionList = (List<Question>) ois.readObject();
//
//	            // Process and display questions, manage game flow...
//	            // ...
//
//	        } catch (Exception e) {
//	            e.printStackTrace();
//	        }
//	 }
	 
	 static void playGame(Person p, int categoryId, ObjectOutputStream oos, ObjectInputStream ois, Socket socket) {
		    try {
//		        List<Question> questionList = (List<Question>) ois.readObject();
		    	String json = (String) ois.readObject();
            	System.out.println("Server Response: " + json);
            	ObjectMapper objectMapper = new ObjectMapper();       
                JSONArray jsonArray = new JSONArray(json);
                List<Question> questionList = new LinkedList();
                // Iterate through the questions
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject questionObject = jsonArray.getJSONObject(i);
                    // Extract question details
                    int id = questionObject.getInt("id");
                    String questionText = questionObject.getString("questionText");
                    int categoryId1 = 0;
                    int answerId = 0;
                    questionList.add(new Question(id, questionText, categoryId1, answerId));
                    System.out.println();
                }
                System.out.println("C: QSZE: "+questionList.size());
		        if (questionList.isEmpty()) {
		            System.out.println("There are no questions available..");
		            return;
		        }

		        int currentIndex = 0;
		        System.out.println("C: Proccessing");
		     // Receive options from the server
		        String json2 = (String) ois.readObject();
		        System.out.println("Server Response: " + json2);
//		        ObjectMapper objectMapper3 = new ObjectMapper();
//		        String json3 = null;
//				try {
//					json3 = (String) ois.readObject();
//				} catch (ClassNotFoundException | IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//		     	System.out.println("Server Response: " + json3);
		     	System.out.println("Server Response: " + json);
		        while (currentIndex < questionList.size()) {
		        	displayQuestionOptions(questionList.get(currentIndex), ois, currentIndex+1, oos);
		            currentIndex++;
		        }

		        System.out.println("\t**GAME OVER**\n");

		        float fractionScore = 100.0f / questionList.size();
		        float percentageScore = fractionScore * p.getTotalWins();

		        System.out.printf("YOUR SCORE IS: %d / %d (%.0f%%)\n", p.getTotalWins(), questionList.size(), percentageScore);

		        p.setTotalWins(0);

		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}
	 
	 private static void displayQuestionOptions(Question question, ObjectInputStream ois, int questionNumber, ObjectOutputStream oos) {
		    try {
//		        System.out.println("\nQUESTION " + questionNumber + ": " + question.getQuestionText() + "\n");
		        //Sending each qn back to the server, to retrieve the options
//		        ObjectMapper objectMapper = new ObjectMapper();
//		    	String json;
//				try {
//					json = objectMapper.writeValueAsString(question);
//					System.out.println("C: JSON Qn sending from client to the server"+json);
//					oos.writeObject(json);
//		        	 // Check if the connection is still open before writing to the output stream
////		            if (!clientSocket.isClosed()) {
////		                oos.writeObject(json);
//		                oos.flush();
////		            }
//				} catch (JsonProcessingException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch(IOException e) {
//					System.out.println("S: error occurred: "+e.getMessage());
//				}
		        
//		        ObjectMapper objectMapper = new ObjectMapper();
		        String json = null;
				try {
					json = (String) ois.readObject();
				} catch (ClassNotFoundException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				if(json!=null)
		     	System.out.println("Server Response: " + json);
		     	// Parse the JSON array
//		         JSONArray jsonArray = new JSONArray(json);
//		         System.out.println("CL SS: "+jsonArray);
//		        JSONArray jsonArray = new JSONArray(json);
//
//		        List<Option> optionsList = new LinkedList<>();
////
////		        // Iterate through the options
//		        for (int i = 0; i < jsonArray.length(); i++) {
//		            JSONObject optionObject = jsonArray.getJSONObject(i);
//		            String optionText = optionObject.getString("optionText");
//		            optionsList.add(new Option(optionText));
//		        }
//
//		        char optionChoice = 'a';
//		        for (Option option : optionsList) {
//		            System.out.println(optionChoice + ". " + option.getOptionText() + "\t");
//		            optionChoice++;
//		        }
//
//		        Scanner sc = new Scanner(System.in);
//		        System.out.println();
//
//		        char choice;
//		        boolean validChoice = false;
//
//		        // Continue prompting until a valid choice (a/b/c/d) is entered
//		        System.out.println("\nEnter your choice (a/b/c/d)...");
//		        while (!validChoice) {
//		            choice = sc.next().toLowerCase().charAt(0);
//
//		            if (choice >= 'a' && choice <= 'd') {
//		                validChoice = true;
//		                oos.writeInt(choice - 'a' + 1);  // Send user's option choice to the server
//		                oos.flush();
//		            } else {
//		                System.out.println("Please enter a valid choice (a/b/c/d).");
//		            }
//		        }

		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}


	    
	    private static void displayOptionsForQuestion(ObjectInputStream ois) {
//	        try {
//	            List<String> options = (List<String>) ois.readObject();
//
//	            if (options.isEmpty()) {
//	                System.out.println("No options available for the selected question.");
//	            } else {
//	                System.out.println("\n*** OPTIONS FOR QUESTION ***\n");
//	                char optionChoice = 'a';
//
//	                for (String option : options) {
//	                    System.out.println(optionChoice + ". " + option);
//	                    optionChoice++;
//	                }
//	            }
//	        } catch (Exception e) {
//	            e.printStackTrace();
//	        }
	    	
	    	String json = "";
			try {
				json = (String) ois.readObject();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	System.out.println("Server Response: " + json);
        	ObjectMapper objectMapper = new ObjectMapper();
        	// Parse the JSON array
            JSONArray jsonArray = new JSONArray(json);

            // Iterate through the questions
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject optionObject = jsonArray.getJSONObject(i);
                String optionText = optionObject.getString("optionText");
                System.out.println("Option "+(i+1)+":" + optionText);
                System.out.println();
            }
	    }
}
