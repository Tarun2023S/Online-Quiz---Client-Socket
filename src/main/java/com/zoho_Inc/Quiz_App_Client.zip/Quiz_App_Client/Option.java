package com.zoho_Inc.Quiz_App_Client;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class Option {
    private String optionText;
    @JsonCreator
    public Option(@JsonProperty("optionText") String optionText) {
        this.optionText = optionText;
    }

    @JsonProperty("optionText")
    public String getOptionText() {
        return optionText;
    }
}
