package com.zoho_Inc.Quiz_App_Client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.*;

import org.json.JSONArray;
import org.json.JSONObject;

public class PlayerManager {
	
	static int validChoices(Scanner sc) {
        int choice = 0;

        while (true) {
            try {
                System.out.println("\t\n*** QUIZ APPLICATION MENU ***\n");
                System.out.println("\t1. Play Game");
                System.out.println("\t3. View All Questions");
//                System.out.println("\t4. View All Options For a Question");
                System.out.println("\t6. EXIT\n");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                break;
            } catch (Exception e) {
                System.out.println("Please enter a valid integer choice.\n");
                sc.next();
            }
        }

        return choice;
    }
	
	 public static void displayQuestions(List<Question> questions) {
	        System.out.println("Questions:");
	        for (Question question : questions) {
	            System.out.println("ID: " + question.getId());
	            System.out.println("Question: " + question.getQuestionText());
	            System.out.println("Category ID: " + question.getCategoryId());
	            System.out.println("Answer ID: " + question.getAnswerId());
	            System.out.println("-----------------------------");
	        }
	    }
	 
	 static void displayOptions(List<Option> options) {
		    for (Option option : options) {
		        System.out.println(option);
		    }
	}
	 
	 static void playGame(Person p, int categoryId, ObjectOutputStream oos, ObjectInputStream ois, Socket socket, int randomFetchNumber) {
		    try {
		    	String json = (String) ois.readObject();
//            	System.out.println("Server Response: " + json);   
                JSONArray jsonArray = new JSONArray(json);
                List<Question> questionList = new LinkedList();
                
                // Iterate through the questions
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject questionObject = jsonArray.getJSONObject(i);
                    // Extract question details
                    int id = questionObject.getInt("id");
                    String questionText = questionObject.getString("questionText");
                    int categoryId1 = questionObject.getInt("categoryId");
                    int answerId = questionObject.getInt("answerId");;
                    questionList.add(new Question(id, questionText, categoryId1, answerId));
                }
		        if (questionList.isEmpty()) {
		            System.out.println("There are no questions available..");
		            return;
		        }
		        
		        if (categoryId != -1 && randomFetchNumber > questionList.size()) {
	                System.out.println("There are only " + questionList.size() + " questions available for this category..");
	            }
		        
		        displayQuestionOptions(questionList, ois, oos);

		        p.setTotalWins(0);

		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}
	 
	private static void displayQuestionOptions(List<Question> questionList, ObjectInputStream ois, ObjectOutputStream oos) {
		int score = 0;
		for (int i = 0; i < questionList.size(); i++) {
	            Question question = questionList.get(i);
	            List<Option> optionList = new ArrayList();
	            String json3;
	            //send the questionId to the server
	            try {
					oos.write(question.getId());
					oos.flush();
					//Receive the corresponding options from the client
					json3 = (String) ois.readObject();
			        JSONArray jsonArray3 = new JSONArray(json3);
			        for (int j = 0; j < jsonArray3.length(); j++) {
	                    JSONObject optionObject = jsonArray3.getJSONObject(j);
	                    int id = optionObject.getInt("optionId");
	                    String optionText = optionObject.getString("optionText");
	                    optionList.add(new Option(id, optionText));
	                }
				} catch (ClassNotFoundException | IOException e) {
					e.printStackTrace();
				}
		        
	            System.out.println("\n  Question " + (i+1)+")   "+ question.getQuestionText()+"\n");

	            // Display options corresponding to the current question
	            int start = 0; // Start index for options
	            int end = start + 4; // End index for options
	            char c = 'a';
	            Map<Character, Integer> choiceIdMap = new HashMap();
	            String correctAnswer = "";
	            int correctAnswerId = question.getAnswerId();
	            for (int j = start; j < end; j++) {
	                if (j < optionList.size()) {
	                    Option option = optionList.get(j);
	                    if(correctAnswerId == option.getOptionId()) {
	                    	correctAnswer = c+". "+option.getOptionText();
	                    }
	                    choiceIdMap.put(c, option.getOptionId());
	                    System.out.print("  "+c+". " + option.getOptionText()+"\t");
	                    c++;
	                }
	            }

	            System.out.println(); // Separate questions
	            
	         // Ask the user to enter their choice
		        System.out.print("\n  Enter your choice (a/b/c/d): ");
		        try {
		        	Scanner sc = new Scanner(System.in);
		        	char userChoice = sc.next().charAt(0);
		            // Validate user choice against the correct answer
		            
		            int userChoiceId = choiceIdMap.get(userChoice);

		            if (userChoiceId == correctAnswerId) {
		            	score++;
		                System.out.println("\n  Correct Answer!" + score);
		            } else {
		                System.out.println("\n  Wrong Answer! The correct answer is: " + correctAnswer);
		            }
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
	        }
		float fractionScore = 100.0f / questionList.size();
		float percentageScore = fractionScore * score;
		System.out.println("\n\t**GAME OVER**\n");
		System.out.printf("  YOUR SCORE IS: %d / %d (%.0f%%)\n", score, questionList.size(), percentageScore);
	}

}
