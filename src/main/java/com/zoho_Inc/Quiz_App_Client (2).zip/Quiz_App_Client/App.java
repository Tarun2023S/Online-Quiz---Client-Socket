package com.zoho_Inc.Quiz_App_Client;

import java.io.*;
import java.net.*;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Hello world!
 *
 */
public class App {
	private static Socket socket = null;
    private static ObjectOutputStream oos = null;
    private static ObjectInputStream ois = null;
    public static void main(String[] args) {
        String url = "localhost";
        int port = 1230;

        try {
            Scanner sc = new Scanner(System.in);
            while (true) {
            	socket = new Socket(url, port);
            	oos = new ObjectOutputStream(socket.getOutputStream());
            	ois = new ObjectInputStream(socket.getInputStream());
            	
                int choice = PlayerManager.validChoices(sc);
                
                oos.writeInt(choice);
                oos.flush();
                
                switch (choice) {
                case 1: {
                	System.out.println("Enter the name of the player you want to play with:");
                	String playerName = sc.next();
                	oos.writeObject(playerName);
                	oos.flush();

                	System.out.println("Enter the category ID: (or)\nTo fetch qns randomly, enter -1");
                	int categoryId1 = sc.nextInt();  // Read the entire line
                	oos.writeInt(categoryId1);
                	oos.flush();
                	
                	System.out.println("Enter the number of questions you want to fetch:");
                	int fetchNumber = sc.nextInt();  // Read the entire line
                	oos.writeInt(fetchNumber);
                	oos.flush();

                	PlayerManager.playGame(new Person("Dummy"), categoryId1, oos, ois, socket, fetchNumber);
                }
                break;
                case 3: {
                	String json = (String) ois.readObject();
                	System.out.println("Server Response: " + json);
                	ObjectMapper objectMapper = new ObjectMapper();
                	
                 // Parse the JSON array
                    JSONArray jsonArray = new JSONArray(json);

                    // Iterate through the questions
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject questionObject = jsonArray.getJSONObject(i);

                        // Extract question details
                        int id = questionObject.getInt("id");
                        String questionText = questionObject.getString("questionText");
                        int categoryId = questionObject.getInt("categoryId");
                        int answerId = questionObject.getInt("answerId");

                        // Display the question details
                        System.out.println("Question " + id + ":");
                        System.out.println("Text: " + questionText);
                        System.out.println("Category ID: " + categoryId);
                        System.out.println("Answer ID: " + answerId);
                        System.out.println();
                    }
                }
                break;
                case 6: {
                	closeEverything(socket, oos, ois);
                	System.out.println("Exiting Quiz Application. Goodbye!");
                	System.exit(0);
                }
                break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
                }
//                if (choice == 4) {
//                    System.out.print("Enter the question ID: ");
//                    int questionId = sc.nextInt();
//                    oos.writeInt(questionId);
//                    oos.flush();
//                }
                
            }
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void closeEverything(Socket socket, ObjectOutputStream objectOutputStream, ObjectInputStream objectInputStream) {
		try {
			if(objectInputStream != null) {
				objectInputStream.close();
			}
			if(objectOutputStream != null) {
				objectOutputStream.close();
			}
			if(socket != null) {
				socket.close();
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
}
