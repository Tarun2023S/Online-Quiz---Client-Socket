package com.zoho_Inc.Quiz_App_Client;

import java.io.*;
import java.net.*;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Hello world!
 *
 */
public class Client {
	private Socket socket = null;
    private ObjectOutputStream oos = null;
    private ObjectInputStream ois = null;
    
    String plname;
    public Client(Socket socket, String plName) {
    	try {
    		this.socket = socket;
        	this.plname = plName;
			this.oos = new ObjectOutputStream(socket.getOutputStream());
			this.ois = new ObjectInputStream(socket.getInputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public static void main(String[] args) {
        String url = "localhost";
        int port = 1230;
        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter player name: ");
//        String plName = sc.nextLine();
//        boolean firstLogin = false;
        Socket socket = null;
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;
        PlayerManager pM = new PlayerManager();
        try {
//        	socket = new Socket(url, port);
//        	Client client = new Client(socket, plName);
        	System.out.println("Connection there");
            while (true) {
            	socket = new Socket(url, port);
            	oos = new ObjectOutputStream(socket.getOutputStream());
            	ois = new ObjectInputStream(socket.getInputStream());
//            	Client client = new Client(socket, plName);
//            	if(!firstLogin) {
//            		oos.writeObject(plName);
//                	oos.flush();
//                	firstLogin = true;
//            	}
            
                int choice = PlayerManager.validChoices(sc);
                oos.writeInt(choice);
                oos.flush();
                
                switch (choice) {
                case 1: {
                	pM.playGameHelper(sc, socket, oos, ois, false);
                }
                break;
                case 2: {
                	pM.playGameHelper(sc, socket, oos, ois, true);
                }
                break;
                case 3: {
                	String json = (String) ois.readObject();
                	System.out.println("Server Response: " + json);
                	ObjectMapper objectMapper = new ObjectMapper();
                	
                 // Parse the JSON array
                    JSONArray jsonArray = new JSONArray(json);

                    // Iterate through the questions
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject questionObject = jsonArray.getJSONObject(i);

                        // Extract question details
                        int id = questionObject.getInt("id");
                        String questionText = questionObject.getString("questionText");
                        int categoryId = questionObject.getInt("categoryId");
                        int answerId = questionObject.getInt("answerId");

                        // Display the question details
                        System.out.println("Question " + id + ":");
                        System.out.println("Text: " + questionText);
                        System.out.println("Category ID: " + categoryId);
                        System.out.println("Answer ID: " + answerId);
                        System.out.println();
                    }
                }
                break;
                case 6: {
                	closeEverything(socket, oos, ois);
//                	socket.close();
                	System.out.println("Exiting Quiz Application. Goodbye!");
                	System.exit(0);
                }
                break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
                }
                
            }
        } catch (SocketException e) {
            // Handle the SocketException (Connection reset) gracefully
        	e.printStackTrace();
            System.out.println("Client disconnected unexpectedly.");
        }
        catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }
    
    
   
    
    public static void closeEverything(Socket socket, ObjectOutputStream objectOutputStream, ObjectInputStream objectInputStream) {
		try {
			if(objectInputStream != null) {
				objectInputStream.close();
			}
			if(objectOutputStream != null) {
				objectOutputStream.close();
			}
			if(socket != null) {
				socket.close();
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
    
    
    
   

}
