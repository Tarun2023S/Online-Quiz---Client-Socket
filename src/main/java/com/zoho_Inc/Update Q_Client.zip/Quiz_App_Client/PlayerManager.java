package com.zoho_Inc.Quiz_App_Client;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

public class PlayerManager {
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private static ScheduledFuture<?> timerHandle;
    static int TIME_LIMIT_SECONDS = 5; // Set the time limit for each question

    static int validChoices(Scanner sc) {
        int choice = 0;

        while (true) {
            try {
                System.out.println("\t\n*** QUIZ APPLICATION MENU ***\n");
                System.out.println("\t1. Play Game");
                System.out.println("\t2. Play timed Game");
//                System.out.println("\t3. Play With Opponent");
                System.out.println("\t4. View All Questions");
                System.out.println("\t6. EXIT\n");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                break;
            } catch (Exception e) {
                System.out.println("Please enter a valid integer choice.\n");
                sc.next();
            }
        }

        return choice;
    }

    public static void displayQuestions(List<Question> questions) {
        System.out.println("Questions:");
        for (Question question : questions) {
            System.out.println("ID: " + question.getId());
            System.out.println("Question: " + question.getQuestionText());
            System.out.println("Category ID: " + question.getCategoryId());
            System.out.println("Answer ID: " + question.getAnswerId());
            System.out.println("-----------------------------");
        }
    }

    static void displayOptions(List<Option> options) {
        for (Option option : options) {
            System.out.println(option);
        }
    }
    
    public void playGameHelper(Scanner sc, Socket socket, ObjectOutputStream oos, ObjectInputStream ois, boolean isTimed) {
    	try {
//    		System.out.println("Enter the name of the player you want to play with:");
//    		String playerName = getUserInputString(sc);
//        	oos.writeObject(playerName);
//        	oos.flush();

        	System.out.println("Enter the category ID: (or)\nTo fetch qns randomly, enter -1");
        	int categoryId1 = getUserInputInt(sc);  // Read the entire line
        	oos.writeInt(categoryId1);
        	oos.flush();
        	
        	if(categoryId1>=3) PlayerManager.TIME_LIMIT_SECONDS = 10;
        	System.out.println("Enter the number of questions you want to fetch:");
        	int fetchNumber = getUserInputInt(sc);  // Read the entire line
        	oos.writeInt(fetchNumber);
        	oos.flush();
        	
        	if(isTimed!=true) {
        		PlayerManager.playGame(new Person("Dummy"), categoryId1, oos, ois, socket, fetchNumber, false);
        	}
        	else {
        		PlayerManager.playGame(new Person("Dummy"), categoryId1, oos, ois, socket, fetchNumber, true);
        	}
    	} catch(SocketException e) {
    		System.out.println("exception occured");
    	} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    static void playGame(Person p, int categoryId, ObjectOutputStream oos, ObjectInputStream ois, Socket socket,
            int randomFetchNumber, boolean isTimed) {
        try {
            String json = "";
            System.out.println("S: jsonMt: "+json);
            json = (String) ois.readObject();
            System.out.println("S: jsonFetch: "+json);
            JSONArray jsonArray = null;
            System.out.println("C: QnsJsonArr0: "+jsonArray);
            jsonArray = new JSONArray(json);
            List<Question> questionList = new ArrayList<>();
            questionList.clear();
            System.out.println("C: QnsJsonArr1: "+jsonArray);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject questionObject = jsonArray.getJSONObject(i);
                int id = questionObject.getInt("id");
                String questionText = questionObject.getString("questionText");
                int categoryId1 = questionObject.getInt("categoryId");
                int answerId = questionObject.getInt("answerId");
                questionList.add(new Question(id, questionText, categoryId1, answerId));
            }

            if (questionList.isEmpty()) {
                System.out.println("There are no questions available..");
                return;
            }

            if (categoryId != -1 && randomFetchNumber > questionList.size()) {
                System.out.println("There are only " + questionList.size() + " questions available for this category..");
            }
            System.out.println("C: Before qns List SZ: "+questionList.size());
            displayQuestionOptions(questionList, ois, oos, isTimed);
            System.out.println("C: Finally qns List SZ: "+questionList.size());
            p.setTotalWins(0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void displayQuestionOptions(List<Question> questionList, ObjectInputStream ois,
            ObjectOutputStream oos, boolean isTimed) {
        int score = 0;
        int currentIndex = 0;
        List<Integer> answerChoiceList = new ArrayList<>();
        int[] scoreArray = new int[questionList.size()];
        int[] answerChoiceArray = new int[questionList.size()];
        Scanner sc = new Scanner(System.in);

        List<List<Option>> allOptionsList = new ArrayList<>();
        getAllOptionsForAQuestion(oos, ois, questionList, allOptionsList);

        while (currentIndex < questionList.size()) {
            System.out.println("currIdx: " + currentIndex);
            Question question = questionList.get(currentIndex);
            List<Option> optionList = allOptionsList.get(currentIndex);

            System.out.println("\n  Question " + (currentIndex + 1) + ")   " + question.getQuestionText() + "\n");

            int start = 0;
            int end = start + 4;
            char c = 'a';
            displayOptions(optionList, start, end, c);

            if (answerChoiceArray[currentIndex] != 0) {
                displayPreviousChoice(optionList, answerChoiceArray[currentIndex]);
            }

            System.out.print("\n  Enter your choice (a/b/c/d): ");
            try {
                if (isTimed) {
                    startTimer();
                }

                char userChoice = sc.next().charAt(0);
                int userChoiceId = validateUserChoice(optionList, userChoice);

                answerChoiceArray[currentIndex] = userChoiceId;

                if (isTimed) {
                    stopTimer();
                    if (!timeExpired) {
                        evaluateUserChoice(optionList, scoreArray, currentIndex, userChoiceId, question.getAnswerId());
                    }
                    System.out.println("Inside time exp: " + currentIndex);
                    currentIndex++;
                    continue;
                } else {
                    evaluateUserChoice(optionList, scoreArray, currentIndex, userChoiceId, question.getAnswerId());

                    System.out.println("\nSelect an option:");
                    System.out.println("1. Move to the next question");
                    System.out.println("2. Move to the previous question");
                    System.out.println("3. Review Question");
                    System.out.println("4. Exit game");

                    int option = sc.nextInt();
                    switch (option) {
                        case 1:
                            currentIndex++;
                            break;
                        case 2:
                            if (currentIndex > 0) {
                                currentIndex--;
                            } else {
                                System.out.println("You are at the first question.");
                            }
                            break;
                        case 3:
                            currentIndex = 0;
                            break;
                        case 4:
                            return;
                        default:
                            System.out.println("Invalid option. Please try again.");
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (isTimed) {
                    stopTimer();
                }
            }
        }

        calculateScore(scoreArray, score, questionList);
    }

    private static void displayOptions(List<Option> optionList, int start, int end, char c) {
        Map<Character, Integer> choiceIdMap = new HashMap<>();
        String correctAnswer = "";
        String correctAnswerChoice = "";
        int correctAnswerId = optionList.get(0).getOptionId();

        for (int j = start; j < end; j++) {
            if (j < optionList.size()) {
                Option option = optionList.get(j);

                if (correctAnswerId == option.getOptionId()) {
                    correctAnswerChoice = "" + c;
                    correctAnswer = option.getOptionText();
                }

                choiceIdMap.put(c, option.getOptionId());
                System.out.print("  " + c + ". " + option.getOptionText() + "\t");
                c++;
            }
        }

        System.out.println();
    }

    private static void displayPreviousChoice(List<Option> optionList, int answerChoice) {
        for (Option o : optionList) {
            if (o.getOptionId() == answerChoice) {
                System.out.println("The previously selected option is " + o.getOptionText());
            }
        }
    }

    private static int validateUserChoice(List<Option> optionList, char userChoice) {
        while (true) {
            if (userChoice >= 'a' && userChoice <= 'd') {
                int userChoiceId = optionList.get(userChoice - 'a').getOptionId();
                return userChoiceId;
            } else {
                System.out.println("Invalid choice. Please enter a valid option (a/b/c/d): ");
                userChoice = new Scanner(System.in).next().charAt(0);
            }
        }
    }

    private static void evaluateUserChoice(List<Option> optionList, int[] scoreArray, int currentIndex, int userChoiceId,
            int correctAnswerId) {
        if (userChoiceId == correctAnswerId) {
            scoreArray[currentIndex] = 1;
            System.out.println("\n  Correct Answer! Your current score is: " + scoreArray[currentIndex]);
        } else {
            scoreArray[currentIndex] = 0;
            System.out.println("\n  Wrong Answer! The correct answer is: " + getCorrectAnswer(optionList, correctAnswerId));
        }
    }

    private static String getCorrectAnswer(List<Option> optionList, int correctAnswerId) {
        for (Option option : optionList) {
            if (option.getOptionId() == correctAnswerId) {
                return option.getOptionText();
            }
        }
        return "";
    }

    private static void calculateScore(int[] scoreArray, int score, List<Question> questionList) {
        for (int i = 0; i < scoreArray.length; i++) {
            if (scoreArray[i] == 1) {
                score++;
            }
        }
        float fractionScore = 100.0f / questionList.size();
        float percentageScore = fractionScore * score;

        System.out.println("\n\t**GAME OVER**\n");
        System.out.printf("  YOUR SCORE IS: %d / %d (%.0f%%)\n", score, questionList.size(), percentageScore);
    }

    private static boolean timeExpired = false;

    private static void startTimer() {
        timerHandle = scheduler.schedule(() -> {
            System.out.println("\nTime's up! Moving to the next question.");
            timeExpired = true;
        }, TIME_LIMIT_SECONDS, TimeUnit.SECONDS);
    }

    private static void stopTimer() {
        timerHandle.cancel(true);
    }

    private static void getAllOptionsForAQuestion(ObjectOutputStream oos, ObjectInputStream ois,
        List<Question> questionList, List<List<Option>> allOptionsList) {
        for (Question question : questionList) {
            List<Option> optionList = new ArrayList<>();
            String json3 = "";

            try {
                oos.writeInt(question.getId());
                oos.flush();
                json3 = (String) ois.readObject();
                JSONArray jsonArray3 = null;
                jsonArray3 = new JSONArray(json3);
                System.out.println("C: OPjSON: "+jsonArray3);
                for (int j = 0; j < jsonArray3.length(); j++) {
                    JSONObject optionObject = jsonArray3.getJSONObject(j);
                    int id = optionObject.getInt("optionId");
                    String optionText = optionObject.getString("optionText");
                    optionList.add(new Option(id, optionText));
                }
                allOptionsList.add(new ArrayList<>(optionList));
            } catch (ClassNotFoundException | IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println("C: AlloptionsSZ: "+allOptionsList.size());
    }
    
    private static String getUserInputString(Scanner sc) {
        String input = "";
        while (input.isEmpty()) {
//            System.out.print("Input should not be empty. Enter again: ");
            input = sc.next();
        }
        return input;
    }

    private static int getUserInputInt(Scanner sc) {
        int input = 0;
        boolean validInput = false;

        while (!validInput) {
            try {
//                System.out.print("Enter a valid integer: ");
                input = sc.nextInt();
                validInput = true;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                sc.next(); // Consume the invalid input
            }
        }

        return input;
    }
}
