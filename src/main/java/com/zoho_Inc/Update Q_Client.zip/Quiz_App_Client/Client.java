package com.zoho_Inc.Quiz_App_Client;

import java.io.*;
import java.net.*;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Client {
	private Socket socket;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    
    String plname;
    public Client(Socket socket, String plName) {
    	try {
    		this.socket = socket;
        	this.plname = plName;
			this.oos = new ObjectOutputStream(socket.getOutputStream());
			this.ois = new ObjectInputStream(socket.getInputStream());
			System.out.println("C: Inside constructor..");
			oos.writeObject(plName);
			oos.flush();
			System.out.println("C: Sent the PlName");
		} catch (IOException e) {
			closeEverything(socket, oos, ois);
			e.printStackTrace();
		}
    }
    
    public static void main(String[] args) {
        String url = "localhost";
        int port = 1230;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter your username for the group chat: ");
		String userName = sc.nextLine();
		try {
			Socket socket = new Socket("localhost", port);
			Client client = new Client(socket, userName);
//			PlayerManager pM = new PlayerManager();
		    client.startGameHelper(sc);
		} catch(Exception e) {
			System.out.println("An exception occured.."+e.getMessage());
		}
    }
   
    
    public static void closeEverything(Socket socket, ObjectOutputStream objectOutputStream, ObjectInputStream objectInputStream) {
		try {
			if(objectInputStream != null) {
				objectInputStream.close();
			}
			if(objectOutputStream != null) {
				objectOutputStream.close();
			}
			if(socket != null) {
				socket.close();
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
    
    public void startGameHelper(Scanner sc) {
    	try {
    		PlayerManager pM = new PlayerManager();
        	System.out.println("Connection there");
            while (true) {
            	System.out.println("C: Enter your choice: ");
                int choice = PlayerManager.validChoices(sc);
                oos.writeInt(choice);
                oos.flush();
                
                switch (choice) {
                case 1: {
                	pM.playGameHelper(sc, socket, oos, ois, false);
                }
                break;
                case 2: {
                	pM.playGameHelper(sc, socket, oos, ois, true);
                }
                break;
                case 3: {
                	
                }
                break;
                case 4: {
                	String json = (String) ois.readObject();
                	System.out.println("Server Response: " + json);
                	ObjectMapper objectMapper = new ObjectMapper();
                	
                 // Parse the JSON array
                    JSONArray jsonArray = new JSONArray(json);

                    // Iterate through the questions
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject questionObject = jsonArray.getJSONObject(i);

                        // Extract question details
                        int id = questionObject.getInt("id");
                        String questionText = questionObject.getString("questionText");
                        int categoryId = questionObject.getInt("categoryId");
                        int answerId = questionObject.getInt("answerId");

                        // Display the question details
                        System.out.println("Question " + id + ":");
                        System.out.println("Text: " + questionText);
                        System.out.println("Category ID: " + categoryId);
                        System.out.println("Answer ID: " + answerId);
                        System.out.println();
                    }
                }
                break;
                case 6: {
                	closeEverything(socket, oos, ois);
//                	socket.close();
                	System.out.println("Exiting Quiz Application. Goodbye!");
                	System.exit(0);
                }
                break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
                }
                
            }
        } catch (SocketException e) {
            // Handle the SocketException (Connection reset) gracefully
        	e.printStackTrace();
            System.out.println("Client disconnected unexpectedly.");
        }
        catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }
    
   

}
